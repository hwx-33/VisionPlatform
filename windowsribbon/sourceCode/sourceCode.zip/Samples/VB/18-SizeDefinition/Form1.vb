﻿Imports RibbonLib
Imports RibbonLib.Controls
Imports RibbonLib.Interop

Namespace _18_SizeDefinition
	Partial Public Class Form1
		Inherits Form
		Public Sub New()
			InitializeComponent()
		End Sub
	End Class
End Namespace
